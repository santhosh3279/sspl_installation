# Frappe Docker Backup Configuration Guide

## Overview
This backup system provides automated, reliable backups for your Frappe/ERPNext Docker deployment.

## What Gets Backed Up
1. **Database** - Complete MariaDB dump with all ERPNext data
2. **Files** - All uploaded files, private files, and attachments
3. **Configuration** - site_config.json and docker-compose.yml
4. **Metadata** - Backup manifest with timestamps and system info

## Directory Structure
```
/opt/backups/frappe/
├── 20250330_020000/          # Full backup (daily)
│   ├── *-database.sql.gz     # Compressed database
│   ├── *-files.tgz           # Public files archive
│   ├── *-private-files.tgz   # Private files archive (attachments)
│   ├── site_config.json      # Site configuration
│   ├── docker-compose.yml    # Docker config
│   └── backup_manifest.txt   # Backup metadata
├── 20250330_080000/          # Another backup
└── db-only/                  # Quick DB backups (every 6 hours)
    ├── 20250330_080000_*.sql.gz
    └── 20250330_140000_*.sql.gz
```

## Installation Steps

### 1. Download and Install
```bash
# Make scripts executable
chmod +x frappe_backup.sh frappe_db_backup.sh frappe_restore.sh frappe_migrate.sh
chmod +x frappe_backup_verify.sh setup_frappe_backups.sh

# Run installation script
sudo ./setup_frappe_backups.sh
```

The installer copies the scripts to `/opt/scripts/v2/`. Any older backup
scripts directly in `/opt/scripts/` are left untouched, so you can keep
using them as a fallback. Both versions store backups in the same place
(`/opt/backups/frappe/`). If the old scripts are still scheduled in cron,
either remove those lines (`sudo crontab -e`) or answer `no` to the
installer's cron question so backups do not run twice.

### 2. Find Your Site Name
```bash
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend ls sites/
```
The site name is usually something like: `erp.yourdomain.com` or `sspl.local`

### 3. Edit Configuration
Update the following in each script:
- `SITE_NAME="your-site-name"` - Replace with your actual site name
- `BACKUP_DIR="/opt/backups/frappe"` - Change if you want different location
- `RETENTION_DAYS=30` - Adjust how long to keep backups on this server
- `LOCAL_KEEP_MIN=20` - Newest N on this server are never deleted by age
- `CLOUD_KEEP=10` - How many backups to keep on each rclone remote
- `RCLONE_REMOTE=""` - Where backups upload to; see below

### 3a. Cloud Destinations

`RCLONE_REMOTE` takes one destination, several, or all of them:

| Value | Backups go to |
|---|---|
| `""` | nowhere — local only |
| `"gdrive:frappe-backups"` | that one remote |
| `"gdrive:frappe-backups mega:frappe-backups"` | both, independently |
| `"*:frappe-backups"` | every remote `rclone listremotes` reports |

The list is space-separated, so folder names may not contain spaces. The panel
writes this line for you — tick the remotes you want under "Cloud backup
(rclone)".

Destinations are independent. Each one gets its own free-space check, its own
upload, and its own `CLOUD_KEEP` retention. A remote that refuses the upload is
a warning, the rest still get their copy, and a remote is pruned **only** when
its own upload succeeded — otherwise pruning to keep-10 a remote that is
missing today's backup would quietly leave you with nine.

`*:` is evaluated on every run, so a remote added next month starts receiving
backups without anyone re-wiring anything. That is the point of it, and also
the risk: **backups contain `site_config.json` and `.env` — your database and
admin credentials.** Every remote in root's rclone config gets them. If the
server's rclone is ever used for anything unrelated, name your destinations
explicitly instead.

### 4. Test Manual Backup
```bash
sudo /opt/scripts/v2/frappe_backup.sh
```

Check if backup was created:
```bash
ls -lh /opt/backups/frappe/
```

## Automated Backup Schedule

### Default Cron Jobs:
- **Full Backup**: 2:00 AM daily (includes DB + files + config)
- **DB Backup**: Every 6 hours (quick database snapshots)
- **Verification**: 3:00 AM Sunday (checks backup integrity)

### View Cron Jobs:
```bash
sudo crontab -l
```

### Edit Cron Schedule:
```bash
sudo crontab -e
```

### Custom Schedule Examples:
```cron
# Hourly DB backups during business hours (9 AM - 6 PM)
0 9-18 * * * /opt/scripts/v2/frappe_db_backup.sh >> /var/log/frappe_db_backup.log 2>&1

# Full backup twice daily (2 AM and 2 PM)
0 2,14 * * * /opt/scripts/v2/frappe_backup.sh >> /var/log/frappe_backup.log 2>&1

# Weekly full backup only (Sunday 3 AM)
0 3 * * 0 /opt/scripts/v2/frappe_backup.sh >> /var/log/frappe_backup.log 2>&1
```

## Backup Retention

On this server: 30 days for full backups, 14 days for DB-only backups — but the
newest **20** of each always survive, however old they are (`LOCAL_KEEP_MIN`).
That floor is not cosmetic: with a plain age-based cleanup, backups that stop
running for longer than the retention window (container down, site renamed,
disk full) leave *every* copy older than the cutoff, and the next successful
run empties the backup folder. The floor keeps the last 20 restore points no
matter how long the gap was. It is the same figure the admin panel's manual
"Clear backups older than 30 days" button uses, so the two cleanups agree.

On the rclone remote (when `RCLONE_REMOTE` is set): the newest **10** of each,
regardless of age. Cloud retention is counted, not dated, because the remote is
pruned by listing it — a backup deleted from this server by any other means
cannot leave an orphaned copy behind in the cloud. The two are independent: the
server can hold 30 days of full backups while the remote holds the last 10.

With the default cron (full backup daily, DB-only every 6 hours), that works
out to roughly 30 full backups and 56 dumps on disk, and 10 of each in the
cloud.

### Adjust Retention:
Edit `RETENTION_DAYS` / `LOCAL_KEEP_MIN` (local) or `CLOUD_KEEP` (remote):
```bash
sudo nano /opt/scripts/v2/frappe_backup.sh
# Change: RETENTION_DAYS=30  to your preferred value
# Change: LOCAL_KEEP_MIN=20  to your preferred value
# Change: CLOUD_KEEP=10      to your preferred value
```

Note: on Google Drive, rclone deletes to the account's trash by default, so
freed quota only returns once the trash is emptied. This is deliberate — it is
the undo path for a mistaken prune — but it means the remote can report itself
full while every byte of the overage is old backups that retention already
threw away. See "Reclaiming trashed space" below.

### Reclaiming Trashed Space:

Before every cloud upload, the backup scripts run
`/opt/scripts/v2/rclone_trash_cleanup.sh`. If the remote has room, it does
nothing. If it does not, it permanently deletes trashed backups — **oldest
first, and only until the shortfall plus 20% has been recovered**. It is not
`rclone cleanup`, which empties the whole trash unconditionally.

Two things keep it from doing more than that:

- It only considers trash **inside the backup folder** `RCLONE_REMOTE` points
  at, and only items named like this project's own backups
  (`20260101_020000/`, `*_erp.sql.gz`, `backup_*.tar`). Everything else in the
  account's trash is left alone unless `--all-trash` is passed by hand.
- It re-reads `rclone about` after **every single delete** and stops on the
  free space it actually observes, never on its own arithmetic. If three
  deletes in a row free nothing measurable (Drive's quota figures can lag by
  minutes), it stops and warns instead of working through the whole trash.

It can never fail a backup: if it cannot make room, the upload is attempted
anyway and the log carries the warning.

```bash
# See what it would delete, without deleting anything
sudo /opt/scripts/v2/rclone_trash_cleanup.sh --remote gdrive:frappe-backups \
     --need-path /opt/backups/frappe/20260101_020000 --dry-run

# Turn it off entirely (per script)
sudo nano /opt/scripts/v2/frappe_backup.sh
# Change: CLEAR_CLOUD_TRASH=yes  to  no
```

Deletions made here are permanent — the items are already in the trash, and
this takes them out of it for good. Selective clearing is a Google Drive
capability; on other backends the script reports that and skips, because
`rclone cleanup` there would empty far more than was asked for.

### MEGA:

MEGA works for backups — upload and retention behave the same as anywhere
else. Its rubbish bin has the same quota problem as Drive's trash, but none of
the tools to work on it: rclone offers no trashed-only listing for MEGA, so
there is nothing to enumerate, sort oldest-first, or stop halfway through. The
only lever is `rclone cleanup mega:`, which empties the whole bin — the exact
unbounded delete the cleanup script exists to avoid.

So on MEGA the problem is prevented instead of repaired. `MEGA_HARD_DELETE=yes`
(the default) makes the retention prune pass `--mega-hard-delete`, which per
rclone's docs *"delete[s] files permanently rather than putting them into the
trash"*. Pruned backups never reach the bin, so the bin never fills.

The trade-off is the one Drive avoids: on MEGA a pruned backup is gone
immediately, with no bin to fish it back out of. Set `MEGA_HARD_DELETE=no` to
keep the undo path — the bin will then accumulate every pruned backup, and
you will have to run `rclone cleanup mega:` yourself when quota runs out.

The flag is only applied when the remote really is a MEGA remote (checked with
`rclone config show`), so Drive and every other backend are untouched by it.
Pointing the cleanup script at a MEGA remote reports all of the above, tells
you how much the bin currently holds, and exits without deleting anything.

Two MEGA-specific cautions: the free tier is 20 GB, and image snapshots alone
run to several GB each. And rclone's docs warn that *"Mega allows duplicate
files which may confuse rclone"* — repeated backup uploads are exactly that
pattern, so `rclone dedupe mega:frappe-backups` is worth knowing about.

### Manual Cleanup:
```bash
# Remove backups older than 60 days
find /opt/backups/frappe -type d -name "20*" -mtime +60 -exec rm -rf {} \;
```

## Restore Process

### 1. List Available Backups:
```bash
ls -lh /opt/backups/frappe/
```

### 2. Restore from Backup:
```bash
sudo /opt/scripts/v2/frappe_restore.sh /opt/backups/frappe/20250330_020000
```

### 3. If the restore fails at the migration step

A restore is two things: loading the data, then running `bench migrate` so the
patches match the app code in the running image. They fail differently, and the
script tells you which one you got.

**"The data was restored, but the migration did NOT finish."** The data loaded
correctly; what did not finish is the patching, so the database is part-patched.
What failed is a patch belonging to one of the apps — usually because the code
in the image is older or newer than the data. Restoring again only puts you back
at this same point: the database was never the problem.

Read the traceback for the app and patch that failed, fix or update that app,
then re-run only the migration:

```bash
sudo /opt/scripts/v2/frappe_migrate.sh
```

If the patch is known-broken upstream and you accept a part-patched database
until it is fixed:

```bash
sudo SSPL_MIGRATE_SKIP_FAILING=yes /opt/scripts/v2/frappe_migrate.sh
```

Or, if this bench has the command — check with
`bench --site your-site-name --help` — mark that one patch as done,
permanently, and migrate again:

```bash
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend \
    bench --site your-site-name bypass-patch <patch.module.name>
```

**"The restore did NOT finish."** No such reassurance — the old database is
gone and the new one is partial. Restore again, from the safety backup the
Restore button took just before this one.

### 4. Manual Restore (if script fails):
```bash
# Copy backup to container
docker compose -f /opt/sspl-erp/docker-compose.yml cp \
    /opt/backups/frappe/20250330_020000/*-database.sql.gz \
    backend:/tmp/

# Enter container
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend bash

# Inside container (use your actual MariaDB root password):
cd frappe-bench
bench --site your-site-name restore \
    --mariadb-root-password <your-root-password> \
    /tmp/*-database.sql.gz
```

## Remote Backup Options

### Option 1: Rsync to Remote Server
Add to backup script:
```bash
# After local backup completes
rsync -avz --delete /opt/backups/frappe/ \
    user@backup-server:/backups/sspl-erp/
```

### Option 2: Rclone (Cloud Storage)
```bash
# Install rclone
curl https://rclone.org/install.sh | sudo bash

# Configure (Google Drive, S3, etc.)
rclone config

# Add to backup script:
rclone copy /opt/backups/frappe/ gdrive:frappe-backups/ \
    --include "20*/**" --max-age 7d
```

### Option 3: AWS S3
```bash
# Install AWS CLI
sudo apt install awscli

# Configure credentials
aws configure

# Add to backup script:
aws s3 sync /opt/backups/frappe/ \
    s3://your-bucket/frappe-backups/ \
    --exclude "*" --include "20*/*"
```

## Monitoring and Alerts

### Check Backup Logs:
```bash
tail -f /var/log/frappe_backup.log
tail -f /var/log/frappe_db_backup.log
```

### Email Alerts (configure in verify script):
```bash
# Install mail utilities
sudo apt install mailutils

# Edit verify script and set:
ALERT_EMAIL="your-email@example.com"

# Test email
echo "Test" | mail -s "Backup Test" your-email@example.com
```

### Disk Space Monitoring:
```bash
# Check backup disk usage
du -sh /opt/backups/frappe/

# Monitor in real-time
watch -n 60 'df -h | grep -E "(Filesystem|backups)"'
```

## Troubleshooting

### Backup Script Fails:
```bash
# Check Docker status
docker compose -f /opt/sspl-erp/docker-compose.yml ps

# Check permissions
ls -la /opt/backups/frappe/

# Run with verbose logging
bash -x /opt/scripts/v2/frappe_backup.sh
```

### Container Not Found:
```bash
# Ensure containers are running
docker compose -f /opt/sspl-erp/docker-compose.yml up -d

# List container names
docker compose -f /opt/sspl-erp/docker-compose.yml ps --format "{{.Service}}"
```

### Database Connection Issues:
```bash
# Check database credentials
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend \
    bench --site your-site-name console

# Inside console:
frappe.conf.db_password
```

### Restore Fails:
```bash
# Ensure site exists
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend \
    bench --site your-site-name list-apps

# If site doesn't exist, create it first:
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend \
    bench new-site your-site-name
```

## Security Best Practices

1. **Encrypt Backups**: Use GPG encryption for sensitive data
   ```bash
   gpg --symmetric --cipher-algo AES256 backup.sql.gz
   ```

2. **Secure Backup Directory**: Restrict permissions
   ```bash
   sudo chmod 700 /opt/backups/frappe
   sudo chown root:root /opt/backups/frappe
   ```

3. **Store Backups Off-Site**: Always maintain remote copies

4. **Test Restores Regularly**: Verify backups work before you need them

5. **Rotate Passwords**: Update MariaDB root password if needed
   ```bash
   docker compose -f /opt/sspl-erp/docker-compose.yml exec db \
       mariadb -u root -p
   # SET PASSWORD = PASSWORD('new-password');
   ```

## Quick Reference Commands

```bash
# Manual full backup
sudo /opt/scripts/v2/frappe_backup.sh

# Manual DB backup
sudo /opt/scripts/v2/frappe_db_backup.sh

# Verify backups
sudo /opt/scripts/v2/frappe_backup_verify.sh

# Restore
sudo /opt/scripts/v2/frappe_restore.sh /path/to/backup

# Migrations alone — retry after a restore or update failed at that step
sudo /opt/scripts/v2/frappe_migrate.sh

# Check cron jobs
sudo crontab -l

# View logs
tail -f /var/log/frappe_backup.log

# Disk usage
du -sh /opt/backups/frappe/*

# Find site name
docker compose -f /opt/sspl-erp/docker-compose.yml exec backend ls sites/
```

## Support
For issues specific to your `ssplbilling` deployment, check:
- Container logs: `docker compose -f /opt/sspl-erp/docker-compose.yml logs`
- Frappe logs: Inside container at `/home/frappe/frappe-bench/logs/`
- Backup logs: `/var/log/frappe_*.log`
