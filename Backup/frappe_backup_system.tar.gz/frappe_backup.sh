#!/bin/bash

# Frappe Docker Backup Script
# Run this script via cron for automated backups

set -e

# Configuration
BACKUP_DIR="/opt/backups/frappe"
SITE_NAME="your-site-name"  # Change this to your site name
COMPOSE_FILE="/opt/sspl-erp/docker-compose.yml"
RETENTION_DAYS=30

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Timestamp for backup files
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "=== Starting Frappe Backup at $(date) ==="

# 1. Trigger Frappe's built-in backup
echo "Running Frappe backup..."
docker compose -f "$COMPOSE_FILE" exec -T backend \
    bench --site "$SITE_NAME" backup \
    --with-files \
    --compress

# 2. Copy backups from container to host
echo "Copying backups to host..."
CONTAINER_BACKUP_DIR="/home/frappe/frappe-bench/sites/$SITE_NAME/private/backups"

# Create dated backup directory
DATED_BACKUP_DIR="$BACKUP_DIR/$TIMESTAMP"
mkdir -p "$DATED_BACKUP_DIR"

# Copy database backup
docker compose -f "$COMPOSE_FILE" exec -T backend \
    bash -c "ls -t $CONTAINER_BACKUP_DIR/*-database.sql.gz | head -1" | \
    xargs -I {} docker compose -f "$COMPOSE_FILE" cp backend:{} "$DATED_BACKUP_DIR/"

# Copy files backup
docker compose -f "$COMPOSE_FILE" exec -T backend \
    bash -c "ls -t $CONTAINER_BACKUP_DIR/*-files.tar | head -1" | \
    xargs -I {} docker compose -f "$COMPOSE_FILE" cp backend:{} "$DATED_BACKUP_DIR/"

# Copy site_config.json
docker compose -f "$COMPOSE_FILE" cp \
    backend:/home/frappe/frappe-bench/sites/$SITE_NAME/site_config.json \
    "$DATED_BACKUP_DIR/"

# 3. Backup docker-compose and configs
echo "Backing up configuration files..."
cp "$COMPOSE_FILE" "$DATED_BACKUP_DIR/"
cp -r /opt/sspl-erp/.env "$DATED_BACKUP_DIR/" 2>/dev/null || true

# 4. Create a manifest file
cat > "$DATED_BACKUP_DIR/backup_manifest.txt" <<EOF
Backup Date: $(date)
Site: $SITE_NAME
Host: $(hostname)
Docker Compose Version: $(docker compose version)
EOF

# 5. Clean up old backups (older than RETENTION_DAYS)
echo "Cleaning up old backups..."
find "$BACKUP_DIR" -type d -name "20*" -mtime +$RETENTION_DAYS -exec rm -rf {} \; 2>/dev/null || true

# 6. Calculate backup size
BACKUP_SIZE=$(du -sh "$DATED_BACKUP_DIR" | cut -f1)
echo "=== Backup completed successfully ==="
echo "Backup location: $DATED_BACKUP_DIR"
echo "Backup size: $BACKUP_SIZE"
echo "=== Backup finished at $(date) ==="

# Optional: Upload to remote storage (uncomment and configure)
# rsync -avz "$DATED_BACKUP_DIR" user@backup-server:/backups/frappe/
# rclone copy "$DATED_BACKUP_DIR" remote:frappe-backups/
