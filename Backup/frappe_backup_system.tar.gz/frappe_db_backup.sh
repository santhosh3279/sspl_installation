#!/bin/bash

# Direct MariaDB Backup Script
# Useful for quick database-only backups

set -e

BACKUP_DIR="/opt/backups/frappe/db-only"
COMPOSE_FILE="/opt/sspl-erp/docker-compose.yml"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=14

mkdir -p "$BACKUP_DIR"

echo "=== Starting Database Backup at $(date) ==="

# Get database credentials from container
DB_NAME=$(docker compose -f "$COMPOSE_FILE" exec -T backend \
    bash -c 'cd frappe-bench && bench get-site-config --site $(ls sites | grep -v "apps.txt\|assets\|common_site_config.json" | head -1) db_name' | tr -d '\r')

DB_PASSWORD=$(docker compose -f "$COMPOSE_FILE" exec -T backend \
    bash -c 'cd frappe-bench && bench get-site-config --site $(ls sites | grep -v "apps.txt\|assets\|common_site_config.json" | head -1) db_password' | tr -d '\r')

# Dump database
docker compose -f "$COMPOSE_FILE" exec -T db \
    mariadb-dump -u root -p"$DB_PASSWORD" "$DB_NAME" \
    --single-transaction \
    --quick \
    --lock-tables=false | gzip > "$BACKUP_DIR/${TIMESTAMP}_${DB_NAME}.sql.gz"

# Clean old backups
find "$BACKUP_DIR" -name "*.sql.gz" -mtime +$RETENTION_DAYS -delete

echo "=== Database backup completed: $BACKUP_DIR/${TIMESTAMP}_${DB_NAME}.sql.gz ==="
